module.exports = async (req, res, next) => {
    res.render('adminNewCustomerView',{title:"Welcome New Customer! add your name"});
};
