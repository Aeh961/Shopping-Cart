module.exports = async (req, res, next) => {
    res.render('addItemView',{title:"add item"});
};
