module.exports = async (req, res, next) => {
    res.render('newCustomerView',{title:"Welcome New Customer! add your name"});
};
