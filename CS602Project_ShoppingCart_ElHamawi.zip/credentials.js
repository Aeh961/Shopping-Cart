module.exports = {
	host: 'cluster0.c1qr6ua.mongodb.net',
	username: 'cs602_user',
	password: 'cs602_secret',
	database: 'cedarsStore'
}

